# auto-save-app

## 项目简介

对于Office系的软件，无需设置监控窗口，只要在文件窗口进行编辑，就能触发自动保存；
其他软件要设置监控的窗口，在打开该窗口的情况下，可以触发自动保存。

## 安装
`pip install lemon_auto_saver`

## 许可证
本项目采用 MIT 许可证。